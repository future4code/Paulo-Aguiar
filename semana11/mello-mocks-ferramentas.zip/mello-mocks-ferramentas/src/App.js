import React, { useState, useEffect } from 'react'
import styled from 'styled-components';
import axios from 'axios';

const TarefaList = styled.ul`
  padding: 0;
  width: 200px;
`

const Tarefa = styled.li`
  text-align: left;
  text-decoration: ${({completa}) => (completa ? 'line-through' : 'none')};
`

const InputsContainer = styled.div`
  display: grid;
  grid-auto-flow: column;
  gap: 10px;
`

const baseUrl = "https://us-central1-labenu-apis.cloudfunctions.net/generic/aula-tarefas"

const App = (props) => {
  const [tarefas, setTarefas] = useState([])
  const [inputValue, setInputValue] = useState('')
  const [filter, setFilter] = useState('')

  useEffect(() => {
    getAllTasks()
  }, [setTarefas])

  const getAllTasks = () => {
    axios.get(baseUrl).then(response => {
      setTarefas(response.data)
    })
  }

  const onChangeInput = (event) => {
    setInputValue(event.target.value)
  }

  const criaTarefa = () => {
    const novaTarefa = {
      texto: inputValue, 
      id: Date.now(), 
      completa: false
    }
    
    setInputValue('');

    axios.post(baseUrl, novaTarefa).then(() => {
      getAllTasks();
    })
  }

  const selectTarefa = async (tarefa) => {
    const tarefaAtualizada = {
      ...tarefa, 
      completa: !tarefa.completa
    }

    await axios.put(`${baseUrl}/${tarefa.id}`, tarefaAtualizada)
    getAllTasks();
  }

  const onChangeFilter = (event) => {
    setFilter(event.target.value)
  }

  const listaFiltrada = tarefas
    .filter(tarefa => {
      switch (filter) {
        case 'pendentes':
          return !tarefa.completa
        case 'completas':
          return tarefa.completa
        default:
          return true
      }
    })

  return (
    <div className="App">
      <h1>Lista de tarefas</h1>
      <InputsContainer>
        <input value={inputValue} onChange={onChangeInput} placeholder={'Nova tarefa'}/>
        <button onClick={criaTarefa}>Adicionar</button>
      </InputsContainer>
      <br/>

      <InputsContainer>
        <label htmlFor={'filter'}>Filtro</label>
        <select value={filter} onChange={onChangeFilter} id={'filter'}>
          <option value="">Nenhum</option>
          <option value="pendentes">Pendentes</option>
          <option value="completas">Completas</option>
        </select>
      </InputsContainer>
      <TarefaList>
        {listaFiltrada.map((tarefa, index) => {
          return (
            <Tarefa
              completa={tarefa.completa}
              onClick={() => selectTarefa(tarefa)}
              key={index}
              data-testid={'item-tarefa'}
            >
              {tarefa.texto}
            </Tarefa>
          )
        })}
      </TarefaList>
    </div>
  )
}

export default App
